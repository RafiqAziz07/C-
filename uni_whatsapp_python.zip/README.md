# Uni Schedule WhatsApp — Python

## 1) Setup
- Install Python 3.10+
- Copy `config.example.json` to `config.json` and fill:
  - `phone_number_id`, `access_token`, `recipients` (["+994..."])
  - `timezone` = "Asia/Baku"
  - `week_base_date` = Monday of a base Üst/Alt week (YYYY-MM-DD)
  - `week_base_type` = "upper" or "lower"
  - `mock_mode`: true while testing

## 2) Preview tomorrow
python uni_whatsapp.py preview

## 3) Send now (dry-run first)
python uni_whatsapp.py send --dry-run
python uni_whatsapp.py send            # real send (mock_mode=false)

## 4) Schedule at 18:00 (Asia/Baku)
- Windows Task Scheduler: Daily at 18:00 → Action: python + arguments "uni_whatsapp.py send"
- Linux cron:
0 18 * * * /usr/bin/python3 /path/to/uni_whatsapp.py send >> /var/log/uni_whatsapp.log 2>&1

Notes:
- Idempotency: won't re-send for the same date unless you pass --force.
- To target a specific date: --date=YYYY-MM-DD.
