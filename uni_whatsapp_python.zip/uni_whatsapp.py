#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Uni Schedule WhatsApp (Python)
- Reads schedule.json (upper/lower week, Mon..Sun) and builds "tomorrow" message
- Sends it to recipients via WhatsApp Cloud API
- Run at 18:00 Asia/Baku via OS scheduler (Windows Task Scheduler / cron)
Usage:
  python uni_whatsapp.py preview [--date=YYYY-MM-DD]
  python uni_whatsapp.py send [--date=YYYY-MM-DD] [--dry-run] [--force]
Config:
  See config.json (created from config.example.json)
"""
import os, sys, json, time, argparse
from datetime import datetime, timedelta, date
try:
    from zoneinfo import ZoneInfo
except ImportError:
    # Python <3.9 fallback
    raise SystemExit("Please use Python 3.9+ (zoneinfo needed).")
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

CONFIG_FILE   = "config.json"
SCHEDULE_FILE = "schedule.json"
LAST_SENT_FILE = ".last_sent.txt"

DAY_KEYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]

DEFAULTS = {
    "phone_number_id": "",
    "access_token": "",
    "recipients": [],  # ["+994501234567", ...]
    "timezone": "Asia/Baku",
    "week_base_date": None,  # default = Monday of current week
    "week_base_type": "upper",  # "upper" or "lower"
    "mock_mode": True,
    "line_template": "{start}-{end} {course} — {teacher} — {room}",
    "header_template": "Sabahın dərs cədvəli — {date_long} ({week_type_az})"
}

def load_json(path):
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_config():
    cfg = DEFAULTS.copy()
    user = load_json(CONFIG_FILE)
    if user:
        cfg.update(user)
    # compute default week_base_date if missing -> Monday this week in TZ
    tz = ZoneInfo(cfg.get("timezone") or "Asia/Baku")
    today = datetime.now(tz).date()
    monday = today - timedelta(days=today.weekday())
    if not cfg.get("week_base_date"):
        cfg["week_base_date"] = monday.isoformat()
    return cfg

def week_type_for_date(target: date, base_date_str: str, base_type: str, tz: ZoneInfo) -> str:
    try:
        base = datetime.strptime(base_date_str, "%Y-%m-%d").date()
    except Exception:
        # fallback: this week's Monday
        today = datetime.now(tz).date()
        base = today - timedelta(days=today.weekday())
    # Align both to Monday of their weeks
    tgt_monday  = target - timedelta(days=target.weekday())
    base_monday = base   - timedelta(days=base.weekday())
    diff_weeks = (tgt_monday - base_monday).days // 7
    same_parity = (diff_weeks % 2 == 0)
    if same_parity:
        return base_type
    return "lower" if base_type == "upper" else "upper"

def week_type_az(t: str) -> str:
    return "Üst həftə" if t == "upper" else "Alt həftə"

def day_key_for_date(d: date) -> str:
    # Monday=0..Sunday=6 → map to Mon..Sun
    return DAY_KEYS[d.weekday()]

def format_message_for(target: date, cfg: dict, sched: dict) -> str:
    tz = ZoneInfo(cfg.get("timezone") or "Asia/Baku")
    week_type = week_type_for_date(target, cfg["week_base_date"], cfg["week_base_type"], tz)
    wk_az = week_type_az(week_type)
    # Date long in English like "Friday, 20 September 2025"
    date_long = target.strftime("%A, %d %B %Y")
    header = cfg["header_template"].replace("{date_long}", date_long).replace("{week_type_az}", wk_az)

    day_key = day_key_for_date(target)
    entries = (sched.get(week_type, {}) or {}).get(day_key, [])

    if not entries:
        return header + "\n" + "Sabah üçün dərs yoxdur."

    lines = []
    for row in entries:
        line = cfg["line_template"]
        line = line.replace("{start}",   str(row.get("start","")))
        line = line.replace("{end}",     str(row.get("end","")))
        line = line.replace("{course}",  str(row.get("course","")))
        line = line.replace("{teacher}", str(row.get("teacher","")))
        line = line.replace("{room}",    str(row.get("room","")))
        lines.append(line.strip())
    return header + "\n" + "\n".join(lines)

def send_whatsapp_text(text: str, cfg: dict, dry_run=False) -> dict:
    recipients = [r.strip() for r in cfg.get("recipients", []) if r.strip()]
    if not recipients:
        return {"ok": False, "sent": 0, "errors": ["No recipients configured."]}

    if dry_run or cfg.get("mock_mode", False):
        for to in recipients:
            print(f"[MOCK] would send to {to}: {text[:80]}...")
        return {"ok": True, "sent": len(recipients), "mock": True}

    token = (cfg.get("access_token") or "").strip()
    pid   = (cfg.get("phone_number_id") or "").strip()
    if not token or not pid:
        return {"ok": False, "sent": 0, "errors": ["Missing WhatsApp credentials."]}

    url = f"https://graph.facebook.com/v20.0/{pid}/messages"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8",
    }
    import json as _json
    sent = 0
    errs = []
    for to in recipients:
        payload = {
            "messaging_product": "whatsapp",
            "to": to,
            "type": "text",
            "text": {"preview_url": False, "body": text}
        }
        data = _json.dumps(payload).encode("utf-8")
        req = Request(url, data=data, headers=headers, method="POST")
        try:
            with urlopen(req, timeout=15) as resp:
                code = resp.getcode()
                body = resp.read().decode("utf-8", errors="ignore")
                if 200 <= code < 300:
                    sent += 1
                else:
                    errs.append(f"{to}: HTTP {code} {body[:200]}")
        except HTTPError as e:
            try:
                body = e.read().decode("utf-8", errors="ignore")
            except Exception:
                body = str(e)
            errs.append(f"{to}: HTTP {e.code} {body[:200]}")
        except URLError as e:
            errs.append(f"{to}: {e.reason}")
        # gentle pacing ~0.3s to be safe
        time.sleep(0.3)
    return {"ok": len(errs)==0, "sent": sent, "errors": errs}

def idempotency_guard(target: date, force: bool) -> bool:
    if force:
        return True
    if not os.path.exists(LAST_SENT_FILE):
        return True
    try:
        with open(LAST_SENT_FILE, "r", encoding="utf-8") as f:
            last = f.read().strip()
        return last != target.isoformat()
    except Exception:
        return True

def mark_sent(target: date):
    try:
        with open(LAST_SENT_FILE, "w", encoding="utf-8") as f:
            f.write(target.isoformat())
    except Exception:
        pass

def parse_args():
    p = argparse.ArgumentParser(description="Uni Schedule WhatsApp (Python)")
    sub = p.add_subparsers(dest="cmd")

    p_prev = sub.add_parser("preview", help="Show the message for tomorrow (or a specific date).")
    p_prev.add_argument("--date", help="YYYY-MM-DD")

    p_send = sub.add_parser("send", help="Send the message to recipients (tomorrow by default).")
    p_send.add_argument("--date", help="YYYY-MM-DD")
    p_send.add_argument("--dry-run", action="store_true", help="Don't hit the API; print only.")
    p_send.add_argument("--force", action="store_true", help="Ignore idempotency and send anyway.")

    return p.parse_args()

def main():
    args = parse_args()
    if not args.cmd:
        print(__doc__)
        return

    cfg = load_config()
    sched = load_json(SCHEDULE_FILE) or {"upper": {}, "lower": {}}

    tz = ZoneInfo(cfg.get("timezone") or "Asia/Baku")
    now = datetime.now(tz)
    if args.date:
        try:
            target = datetime.strptime(args.date, "%Y-%m-%d").date()
        except ValueError:
            print("Invalid --date. Use YYYY-MM-DD")
            return
    else:
        target = (now + timedelta(days=1)).date()  # 'tomorrow'

    msg = format_message_for(target, cfg, sched)

    if args.cmd == "preview":
        print(msg)
        return

    if args.cmd == "send":
        if not idempotency_guard(target, force=args.force):
            print(f"Already sent for {target.isoformat()} (use --force to override).")
            return
        res = send_whatsapp_text(msg, cfg, dry_run=args.dry_run)
        print(res)
        if res.get("ok"):
            mark_sent(target)
        return

if __name__ == "__main__":
    main()
